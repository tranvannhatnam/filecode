﻿package com.example.firebase2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    //Khoi tao du lieu Firebase
    DatabaseReference mData;
    //Tao cac item tren man hinh
    TextView txtLed, txtHum, txtTemp, txtServo;
    Button btnOn;
    Button btnOff;
    SeekBar skServo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Anh xa cac Item
        txtLed = (TextView) findViewById(R.id.textViewLed);
        txtHum = (TextView) findViewById(R.id.textViewHum);
        txtTemp =(TextView) findViewById(R.id.textViewTemp);
        txtServo=(TextView) findViewById((R.id.textViewServo));
        btnOn= (Button) findViewById(R.id.buttonOn);
        btnOff= (Button) findViewById(R.id.buttonOff);
        skServo= (SeekBar) findViewById((R.id.seekBarServo));

        //Khoi tao ket noi Firebase
        mData= FirebaseDatabase.getInstance().getReference();


        //Nhan du lieu tu Firebase
        mData.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                txtLed.setText(dataSnapshot.child("LedState").getValue().toString());
                txtHum.setText(dataSnapshot.child("huminity").getValue().toString());
                txtTemp.setText(dataSnapshot.child("temp").getValue().toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
      	mData.child("humunity").addValueEventListener(new ValueEventListener() {
           @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
             txtHum.setText(dataSnapshot.getValue().toString());
          }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        //Điều khiển button bat den
        btnOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mData.child("LedState").setValue(1);
            }
        });
        //Dieu khien button tat den
        btnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mData.child("LedState").setValue(0);
            }
        });
        //Dieu khien seek bar Servo
        skServo.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtServo.setText(Integer.toString(i));
                mData.child("servoAngle").setValue(i);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        }
    }

